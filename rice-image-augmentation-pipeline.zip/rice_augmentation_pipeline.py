# CONFIGURATION
drive_folder_id = "1VrZ85O7heCWxbqJNfkc4f4ytrajRork5"  # Replace with your folder ID
target_augmented_images = 1000
output_subfolder = "7"

!pip install tensorflow gdown tqdm matplotlib

import os
import numpy as np
import cv2
import shutil
import io
import random
import gc
from scipy.ndimage import zoom
from tensorflow.keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array
from google.colab import drive, auth
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import google.auth

# Authenticate and mount Drive
auth.authenticate_user()
creds, _ = google.auth.default()
service = build('drive', 'v3', credentials=creds)
drive.mount('/content/drive')

# Clean temporary folders
for folder in ['/content/temp_rice_source', '/content/augmented_temp']:
    if os.path.exists(folder):
        shutil.rmtree(folder)

gc.collect()

# Utility: List and download images
def list_drive_files(service, folder_id):
    query = f"'{folder_id}' in parents and mimeType contains 'image'"
    files = []
    page_token = None
    while True:
        results = service.files().list(q=query, pageToken=page_token).execute()
        files.extend(results.get('files', []))
        page_token = results.get('nextPageToken')
        if not page_token:
            break
    return files

def download_images_from_drive(folder_id, destination_folder):
    files = list_drive_files(service, folder_id)
    if not files:
        print("No images found.")
        return
    os.makedirs(destination_folder, exist_ok=True)
    for file in files:
        request = service.files().get_media(fileId=file['id'])
        fh = io.BytesIO()
        downloader = MediaIoBaseDownload(fh, request)
        done = False
        while not done:
            _, done = downloader.next_chunk()
        with open(os.path.join(destination_folder, file['name']), 'wb') as f:
            f.write(fh.getvalue())
    print(f"Downloaded {len(files)} images.")

# Data augmentation settings
datagen = ImageDataGenerator(
    rotation_range=25,
    width_shift_range=0.15,
    height_shift_range=0.15,
    shear_range=0.1,
    zoom_range=[0.9, 1.1],
    horizontal_flip=True,
    vertical_flip=True,
    fill_mode='reflect'
)

# Optional: Custom augmentation
def apply_custom_augmentations(image):
    img_array = img_to_array(image)
    height, width, _ = img_array.shape
    crop_size = int(min(height, width) * random.uniform(0.85, 0.95))
    start_x = random.randint(0, width - crop_size)
    start_y = random.randint(0, height - crop_size)
    img_array = img_array[start_y:start_y+crop_size, start_x:start_x+crop_size]
    img_array = cv2.resize(img_array, (width, height))
    angle = random.uniform(-25, 25)
    M = cv2.getRotationMatrix2D((width // 2, height // 2), angle, 1.0)
    img_array = cv2.warpAffine(img_array, M, (width, height), borderMode=cv2.BORDER_REFLECT)
    zoom_factor = random.uniform(0.9, 1.1)
    zoomed = zoom(img_array, (zoom_factor, zoom_factor, 1), order=1)
    zoomed = cv2.resize(zoomed, (width, height)) if zoomed.shape[0] <= height else zoomed
    return np.clip(zoomed, 0, 255).astype(np.uint8)

# Main augmentation function
def augment_images(source_path, dest_path, target_count=1000):
    os.makedirs(dest_path, exist_ok=True)
    image_files = [f for f in os.listdir(source_path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    if not image_files:
        print("No images found.")
        return
    for i, filename in enumerate(image_files):
        shutil.copy2(os.path.join(source_path, filename), os.path.join(dest_path, f"original_{i}_{filename}"))
    num_originals = len(image_files)
    num_to_generate = target_count - num_originals
    if num_to_generate <= 0:
        print("Enough images already.")
        return
    augmentations_per_image = max(num_to_generate // num_originals + 1, 4)
    generated_count = 0
    for i, filename in enumerate(image_files):
        if generated_count >= num_to_generate:
            break
        img_path = os.path.join(source_path, filename)
        try:
            img = load_img(img_path, target_size=(512, 512))
            x = img_to_array(img)
            x = np.expand_dims(x, axis=0)
            aug_iter = datagen.flow(x, batch_size=1, save_to_dir=dest_path, save_prefix=f'aug_{i}', save_format='jpg')
            for j in range(min(augmentations_per_image, num_to_generate - generated_count)):
                next(aug_iter)
                generated_count += 1
        except Exception as e:
            print(f"Error processing {filename}: {e}")
    print(f"Generated {generated_count} augmented images.")

# Run
temp_source = "/content/temp_rice_source"
temp_output = "/content/augmented_temp"
final_output = f"/content/drive/MyDrive/rice_new_pics{output_subfolder}"

download_images_from_drive(drive_folder_id, temp_source)
augment_images(temp_source, temp_output, target_augmented_images)

if os.path.exists(final_output):
    shutil.rmtree(final_output)
shutil.move(temp_output, final_output)
shutil.rmtree(temp_source)
print("Image augmentation pipeline completed.")
